<?php
/**
 * Template Name: Calendar
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
	

}

get_header(); 

?>


	<div id="primary" <?php generate_do_element_classes( 'content' ); ?>>
		<main id="main" <?php generate_do_element_classes( 'main' ); ?>>
		    <h1><?php echo __('Motorcycle Tours Calendar', 'khl_template'); ?></h1>
		    <div class="tours-cont">
            
			<?php
			setlocale(LC_ALL, 'nl_NL');
			$tour_days = get_post_meta($post->ID, 'khl_tour_details_khl_days', true);
			    $args = array(  
                'post_type' => 'khl_tour',
                'post_status' => 'publish',
                'posts_per_page' => 8,
                'orderby' => 'title', 
                'order' => 'ASC',
                );

            $loop = new WP_Query( $args ); 
            $tours_array = array(
                );
            $today = date("jS F");

            while ( $loop->have_posts() ) : 
                $loop->the_post(); 
                $tour_url = rtrim(get_permalink( $post->ID ), '/');
			    $tour_book_url = $tour_url . '#book-now';
			    $tour_start = get_post_meta($post->ID, 'khl_tour_details_khl_start', true);
			    $tour_end = get_post_meta($post->ID, 'khl_tour_details_khl_end', true);
			    $tour_start2 = get_post_meta($post->ID, 'khl_tour_details_khl_start2', true);
			    $tour_end2 = get_post_meta($post->ID, 'khl_tour_details_khl_end2', true);
			    $tour_start3 = get_post_meta($post->ID, 'khl_tour_details_khl_start3', true);
			    $tour_end3 = get_post_meta($post->ID, 'khl_tour_details_khl_end3', true);
			    $tour_start4 = get_post_meta($post->ID, 'khl_tour_details_khl_start4', true);
			    $tour_end4 = get_post_meta($post->ID, 'khl_tour_details_khl_end4', true);
			    $tour_start5 = get_post_meta($post->ID, 'khl_tour_details_khl_start5', true);
			    $tour_end5 = get_post_meta($post->ID, 'khl_tour_details_khl_end5', true);
			    $tour_start6 = get_post_meta($post->ID, 'khl_tour_details_khl_start6', true);
			    $tour_end6 = get_post_meta($post->ID, 'khl_tour_details_khl_end6', true);
			    

			    if($tour_start2) {
			        $sdate2 = DateTime::createFromFormat("Ymd", $tour_start2);
			        $s_start = $sdate2->format('jS F');
			        $edate2 = DateTime::createFromFormat("Ymd", $tour_end2);
			        $s_end = $edate2->format('jS F');
			    }
			    if($tour_start3) {
			        $sdate3 = DateTime::createFromFormat("Ymd", $tour_start3);
			        $t_start = $sdate3->format('jS F');
			        $edate3 = DateTime::createFromFormat("Ymd", $tour_end3);
			        $t_end = $edate3->format('jS F');
			    }
			    if($tour_start4) {
			        $sdate4 = DateTime::createFromFormat("Ymd", $tour_start4);
			        $fo_start = $sdate4->format('jS F');
			        $edate4 = DateTime::createFromFormat("Ymd", $tour_end4);
			        $fo_end = $edate4->format('jS F');
			        
			    }
			    if($tour_start5) {
			        $sdate5 = DateTime::createFromFormat("Ymd", $tour_start5);
			        $fi_start = $sdate5->format('jS F');
			        $edate5 = DateTime::createFromFormat("Ymd", $tour_end5);
			        $fi_end = $edate5->format('jS F');
			    }
			    if($tour_start6) {
			        $sdate6 = DateTime::createFromFormat("Ymd", $tour_start6);
			        $si_start = $sdate6->format('jS F');
			        $edate6 = DateTime::createFromFormat("Ymd", $tour_end6);
			        $si_end = $edate6->format('jS F');
			        
			    }
			    
			    $sdate = DateTime::createFromFormat("Ymd", $tour_start);
			    $f_start = $sdate->format('jS F');
			    $edate = DateTime::createFromFormat("Ymd", $tour_end);
                $f_end = $edate->format('jS F');
        
                
                $tour_title = $post->post_title;
                $tour_highlights = get_post_meta($post->ID, 'khl_tour_details_khl_highlights', true);
                $tour_days = get_post_meta($post->ID, 'khl_tour_details_khl_days', true);
                $tour_min_price = get_post_meta($post->ID, 'khl_tour_prices_khl_passenger', true);
                
                $new_tour =  
                    array( 
                        "tour_fsdate" => $f_start,
                        "tour_fedate" => $f_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour);
                if($tour_start2) {
                    $new_tour2 =  
                    array( 
                        "tour_fsdate" => $s_start,
                        "tour_fedate" => $s_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour2);
                }
                if($tour_start3) {
                    $new_tour3 =  
                    array( 
                        "tour_fsdate" => $t_start,
                        "tour_fedate" => $t_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour3);
                }
                if($tour_start4) {
                    $new_tour4 =  
                    array( 
                        "tour_fsdate" => $fo_start,
                        "tour_fedate" => $fo_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour4);
                }
                if($tour_start5) {
                    $new_tour5 =  
                    array( 
                        "tour_fsdate" => $fi_start,
                        "tour_fedate" => $fi_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour5);
                }
                if($tour_start6) {
                    $new_tour6 =  
                    array( 
                        "tour_fsdate" => $si_start,
                        "tour_fedate" => $si_end,
                        "tour_title" => $tour_title,
                        "tour_url" => $tour_url,
                        "tour_book_url" => $tour_book_url,
                        "tour_destinations" => $tour_highlights,
                        "tour_duration" => $tour_days,
                        "tour_price" => $tour_min_price,
                        );
                        array_push($tours_array, $new_tour6);
                }

                //print 'Date: ' . $dateTime . '   ' . $tour_title . 'Destinations: ' . $tour_highlights . ' Duration: ' . $tour_days . '  Prices from: ' . $tour_min_price . ' EUR    <br /> '; 
                
            endwhile;
            
            echo"<br /><br /><br />";
            function date_compare($a, $b) {
                    $t1 = strtotime($a["tour_fsdate"]);
                    $t2 = strtotime($b["tour_fsdate"]);
                    return $t1 - $t2;
                }    
                usort($tours_array, 'date_compare');
                
                
                
            ?>
            <div class="tours-calendar">
            <ul class="calendar-list calendar-bold hide-on-mobile hide-on-tablet"><li class="calendar-19"><?php echo __('Date', 'khl_template'); ?></li>
                            <li class="calendar-18"><?php echo __('Tour', 'khl_template'); ?></li>
                            <li class="calendar-18"><?php echo __('Highlights', 'khl_template'); ?></li>
                            <li class="calendar-21 cal-center"><?php echo __('Duration', 'khl_template'); ?></li>
                            <li class="calendar-10"><?php echo __('Price from', 'khl_template'); ?></li>
                            <li class="calendar-14"></li></ul>    
            
            <p><strong><b><?php echo __('June', 'khl_template'); ?> 2021</b></strong></p>
            <?php
            foreach ($tours_array as $tour_arr) {
                if($tour_arr && strpos($tour_arr["tour_fsdate"], 'June') !== false) {
                    
                        echo '<s><ul class="calendar-list"><li class="calendar-19">' . date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' .  date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14">' . __('Book Now', 'khl_template') . '</a></li></ul></s>';   
                    
                    
                }
            }
            ?>
            <p><strong><b><?php echo __('July', 'khl_template'); ?> 2021</b></strong></p>
            <?php
            foreach ($tours_array as $tour_arr) {
                if($tour_arr && strpos($tour_arr["tour_fsdate"], 'July') !== false) {
                    if (strtotime($tour_arr["tour_fsdate"]) < time()) {
                        echo '<s><ul class="calendar-list"><li class="calendar-19">' .  date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' . date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14">' . __('Book Now', 'khl_template') . '</li></ul></s>';   
                    
                    } else {
                        echo '<ul class="calendar-list"><li class="calendar-19">' . date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' . date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14"><a href="' . $tour_arr["tour_book_url"] . '">' . __('Book Now', 'khl_template') . '</a></li></ul>'; 
                    }
                }
            }
            ?>
            <p><strong><b><?php echo __('August', 'khl_template'); ?> 2021</b></strong></p>
            <?php
            foreach ($tours_array as $tour_arr) {
                if($tour_arr && strpos($tour_arr["tour_fsdate"], 'August') !== false) {
                    
                        echo '<ul class="calendar-list"><li class="calendar-19">' . date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' . date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14"><a href="' . $tour_arr["tour_book_url"] . '">' . __('Book Now', 'khl_template') . '</a></li></ul>'; 
                    
                }
            }
            ?>
            <p><strong><b><?php echo __('September', 'khl_template'); ?> 2021</b></strong></p>
            <?php
            foreach ($tours_array as $tour_arr) {
                if($tour_arr && strpos($tour_arr["tour_fsdate"], 'September') !== false) {
                    if ($tour_arr["tour_fsdate"] < $today_date) {
                        echo '<s><ul class="calendar-list"><li class="calendar-19">' . date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' . date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14"><a href="' . $tour_arr["tour_book_url"] . '">' . __('Book Now', 'khl_template') . '</a></li></ul></s>';   
                    
                    } else {
                        echo '<ul class="calendar-list"><li class="calendar-19">' . date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' . date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14"><a href="' . $tour_arr["tour_book_url"] . '">' . __('Book Now', 'khl_template') . '</a></li></ul>'; 
                    }
                }
            }
            ?>
            <p><strong><b><?php echo __('October', 'khl_template'); ?> 2021</b></strong></p>
            <?php
            echo '<ul class="calendar-list"><li class="calendar-19">' .  date_i18n("d F", strtotime('10/01')) . ' - ' .  date_i18n("d F", strtotime('10/14')) . '</li>
                            <li class="calendar-19"><h3>Turkey</h3></li>
                            <li class="calendar-19">Turkey</li>
                            <li class="calendar-19 cal-center">13</li>
                            <li class="calendar-10">Coming soon</li>
                            <li class="calendar-14">Coming Soon</li></ul>'; 
            foreach ($tours_array as $tour_arr) {
                if($tour_arr && strpos($tour_arr["tour_fsdate"], 'October') !== false) {
                    echo '<ul class="calendar-list"><li class="calendar-19">' .  date_i18n("d F", strtotime($tour_arr["tour_fsdate"])) . ' - ' .  date_i18n("d F", strtotime($tour_arr["tour_fedate"])) . '</li>
                            <li class="calendar-19"><h3>' . $tour_arr["tour_title"] . '</h3></li>
                            <li class="calendar-19">' . $tour_arr["tour_destinations"] . '</li>
                            <li class="calendar-19 cal-center">' . $tour_arr["tour_duration"] . ' ' . __('days', 'khl_template') . '</li>
                            <li class="calendar-10">' . $tour_arr["tour_price"] . ' EUR</li>
                            <li class="calendar-14"><a href="' . $tour_arr["tour_book_url"] . '">' . __('Book Now', 'khl_template') . '</a></li></ul>'; 
                }
            }
            ?>
            </div>
			</div>
		</main>
	</div>

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();

	get_footer();